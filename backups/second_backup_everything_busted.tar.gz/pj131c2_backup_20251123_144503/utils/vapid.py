"""
VAPID key management utilities
"""
import os
from py_vapid import Vapid01 as Vapid
from cryptography.hazmat.primitives import serialization
import base64

VAPID_PRIVATE_KEY = None
VAPID_PUBLIC_KEY = None
VAPID_CLAIMS = {
    "sub": "mailto:admin@browserc2.local"
}


def init_vapid_keys():
    """Initialize or load VAPID keys"""
    global VAPID_PRIVATE_KEY, VAPID_PUBLIC_KEY
    
    private_key_file = 'private_key.pem'
    public_key_file = 'public_key.pem'
    
    if os.path.exists(private_key_file) and os.path.exists(public_key_file):
        # Load existing keys
        VAPID_PRIVATE_KEY = open(private_key_file, 'r').read()
        VAPID_PUBLIC_KEY = open(public_key_file, 'r').read().strip()
    else:
        # Generate new keys
        vapid = Vapid()
        vapid.generate_keys()
        
        # Save private key
        with open(private_key_file, 'w') as f:
            f.write(vapid.private_pem().decode('utf-8'))
        
        # Save public key
        vapid.save_public_key(public_key_file)
        
        VAPID_PRIVATE_KEY = vapid.private_pem().decode('utf-8')
        
        with open(public_key_file, 'r') as f:
            VAPID_PUBLIC_KEY = f.read().strip()
        
        print(f"[+] Generated new VAPID keys")
    
    print(f"[+] VAPID Public Key loaded")


def get_vapid_private_key():
    """Get VAPID private key"""
    return VAPID_PRIVATE_KEY


def get_vapid_public_key():
    """Get VAPID public key"""
    return VAPID_PUBLIC_KEY


def get_vapid_claims():
    """Get VAPID claims"""
    return VAPID_CLAIMS
