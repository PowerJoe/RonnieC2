"""
Push notification utilities
"""
from pywebpush import webpush, WebPushException
import json
from vapid_keys import VAPID_PRIVATE_KEY, VAPID_CLAIMS


def send_push_notification(agent, command, title, message, url, icon):
    """
    Send push notification to an agent
    
    Args:
        agent: Agent object
        command: Command object
        title: Notification title
        message: Notification message
        url: Target URL
        icon: Notification icon
    
    Returns:
        bool: True if sent successfully, False otherwise
    """
    try:
        subscription_info = agent.get_push_subscription()
        
        notification_data = {
            'title': title,
            'body': message,
            'icon': icon,
            'data': {
                'url': url,
                'agent_id': agent.agent_id,
                'command_id': command.id if command else None
            }
        }
        
        webpush(
            subscription_info=subscription_info,
            data=json.dumps(notification_data),
            vapid_private_key=VAPID_PRIVATE_KEY,
            vapid_claims=VAPID_CLAIMS
        )
        
        print(f"[+] Push notification sent to agent {agent.agent_id}")
        return True
        
    except WebPushException as e:
        print(f"[-] WebPush error for agent {agent.agent_id}: {str(e)}")
        if e.response and e.response.status_code == 410:
            print(f"[!] Subscription expired for agent {agent.agent_id}")
        return False
        
    except Exception as e:
        print(f"[-] Push notification error: {str(e)}")
        return False
